package project;


public class AccountType 
{
    private int AccountID; //Holds the AccountID value
    private double InterestRate; //holds the calculated interestRate
    
    public AccountType() //default constructor that sets all to zero
    {
        AccountID =0;
        InterestRate = 0;
    }
    public AccountType(int AccountID) //overloaded constructor to get AccountID(type)
    {
        this.AccountID = AccountID;
        calcinterest(); //calculates the interestrate percentage
    }
    public double getInterestRate() //returns interestRate
    {
        return InterestRate;
    }
    private void calcinterest() //determines the interest level
    {
        if(AccountID == 1) //checking account
            InterestRate = .01;
        else if(AccountID == 2)//savings account
            InterestRate = .02;
        else//error
            InterestRate = 0.0;
    }
    public int getAccountID()//return AccountID
    {
        return AccountID;
    }
    public void setAccountID( int AccountID) //change AccountID value
    {
        this.AccountID = AccountID;
        calcinterest();
    }
}
