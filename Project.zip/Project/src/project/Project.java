  /*

   Programmer: Trent Giever
   Assignment Chapter: Final Project
   Purpose: Capstone of learned Materials
   Date modified: 6/7/2020
   IDE/Tool used: NetBeans 8.2

   */
package project;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Project 
{

    public static void main(String[] args) 
    {
        ArrayList<BankCustomer> customers = new ArrayList<>(); //array of BankCustomers
        int display =3; //int value used for the user loop, default is set to exit
        Scanner keyboard = new Scanner(in); //scanner object
        do
        {
            out.println("Enter a 1 for Manager, 2 for Customer, and 3 to exit"); //prompt
            display = keyboard.nextInt(); //get in the user choice
            if(display == 1) //if manager chosen
            {
               manager(customers,keyboard); //call the manager method
                
            }
            else if(display == 2) //if customer is chosen
            {
                customer(customers, keyboard); //call the customer method
            }
            else if(display !=3)//if input is not 1,2, or 3 display an error message
            {
                out.println("Invaild Number");
            }
        } while(display !=3); //exit when a 3 occurs

    }
    private static void manager(ArrayList<BankCustomer> customers, Scanner keyboard)  //manager method
    {
        int managerInput = 7; //user input for prompt, default is exit
        out.println("Wecome Manager"); //welcome message
        do 
        {
        out.println("Enter a 1 to enter in a new cutomer, 2 to display records, 3 to add to a customers balance, "
                + "\n4 to withdraw from a customers balance, 5 to write to disk, 6 to calculate interest, and 7 to exit");//prompt
        managerInput = keyboard.nextInt(); //gets in the users choice
        //BankCustomer(int CustomerID, double balance, String name, String email, int AccountID) 
        switch(managerInput) //switch case for the 7 choices
        {
            case 1: //enter a new customer, and gets in the needed values
                out.println("Lets enter a new Customer"); 
                out.print("Enter CustomerID: "); 
                int id = keyboard.nextInt();
                keyboard.nextLine();
                out.print("Enter Customer name: ");
                String name = keyboard.nextLine();
                out.print("Enter Customer email: ");
                String email = keyboard.nextLine();
                out.print("Enter a 1 for checking or a 2 for savings account: ");
                int type = keyboard.nextInt();
                out.print("Enter starting balance: ");
                double bal = keyboard.nextDouble();
               BankCustomer temp = new BankCustomer(id,bal,name, email, type); //creates a BankCustomer object from the input
               customers.add(temp); //adds the BankCustomer to the array
               break;
            case 2: //display records by using a loop
                out.println("\nThe Customers are");
                for(int i = 0; i < customers.size(); i++)
                {
                    out.println(customers.get(i));
                }
                out.println();
                break;
            case 3: //update customer balance by deposit
                out.println("\nWelcome to the Customer Help Desk");
                out.print("Enter the Customer ID for the customer that you want to update: ");
                int searchid = keyboard.nextInt(); //enter in CustomerID to search for
                boolean found = false; 
                for(int i = 0; i < customers.size() && !found; i++) //loop through the array
                {
                    if(customers.get(i).getCustomerID() == searchid) //if id matches
                    {
                        found = true; //found
                        out.print("Found the customer");
                        int stop =2;//stops the loop if 2 is entered
                        do //loop to allow as many deposits as desired
                        {
                            out.print("Enter a 1 to deposit, 2 to exit loop: ");
                            stop = keyboard.nextInt(); 
                            double amt =0;
                            if(stop == 1) //if deposit is selected
                            {
                                out.print("What amount: ");
                                amt = keyboard.nextInt();
                            
                                customers.get(i).deposit(amt);
                            }
                            else if(stop !=2) //if error
                                out.println("Error try again");
                        }while(stop !=2); //not equal to stop value
                    }
                }
                if(!found) //if not found display error
                {
                    out.println("Invaild CustomerID");
                }
                        break;
            case 4: //same as deposit, but for withdraw
                out.println("\nWelcome to the Customer Help Desk");
                out.print("Enter the Customer ID for the customer that you want to update: ");
                int searchids = keyboard.nextInt();
                boolean Found = false;
                for(int i = 0; i < customers.size() && !Found; i++)
                {
                    if(customers.get(i).getCustomerID() == searchids)
                    {
                        Found = true;
                        out.print("Found the customer");
                        int stop =2;
                        do
                        {
                            out.print("Enter a 1 to withdraw, 2 to exit loop: ");
                            stop = keyboard.nextInt();
                            double amt =0;
                            if(stop == 1)
                            {
                                out.print("What amount: ");
                                amt = keyboard.nextInt();
                           
                                customers.get(i).withdraw(amt);
                            }
                            else if(stop !=2)
                                out.println("Error try again");
                        }while(stop !=2);
                    }
                }
                if(!Found)
                {
                      out.println("Invaild CustomerID");
                }
                        break;
                        
            case 5: //write to disk the customer informaton
                 File file = new File("BankCustInfo.txt"); //file object
                 { 
            try {
                file.createNewFile(); //creates file if does not exist
            } catch (IOException ex) {
                Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
                            PrintWriter outputFile;
        try {
            outputFile = new PrintWriter(file); //printwriter object
              for(int i = 0; i < customers.size(); i++) //loop through each customer to write to disk with comma sperated values
                            {
                                outputFile.println(customers.get(i).getCustomerID()+"," + customers.get(i).getName()+","+customers.get(i).getEmail());
                            }
                            outputFile.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
        }
                          ;
                            break;
                
             case 6: //calculate interest for all members, manager only ability
                for(int i = 0; i < customers.size(); i++)
                {
                    customers.get(i).getInterest();
                }
                break;
            case 7: //blank for exit
                break;
            default://if not 1-7 then display an error
                out.println("Invalid number try again");
                break; 
            }
   
        } while (managerInput != 7); //exit when 7 entered
        
    }
    private static void customer(ArrayList<BankCustomer> customers, Scanner keyboard) //bank customer object
    {
        int index = -1;//loop until the custome is found, default not found
        out.println("Welcome Customer");
        do
        {
            out.print("enter your Customer ID: ");
            int id = keyboard.nextInt(); //user customer ID
            for(int i = 0; i < customers.size(); i ++)
            {
            if(customers.get(i).getCustomerID() == id) //found
                index = i; //changes the index for use in the other options
            }
            if(index == -1) //error
            out.println("Try Again");
        } while(index ==-1);
        int custInput = 4; //users options, default exit
        do
        {
            out.print("Enter a 1 to deposit, 2 to withdraw, 3 to display, and 4 to exit: ");
            custInput = keyboard.nextInt(); //enter in choice
            switch(custInput)
            {
                case 1: //deposit
                    out.println("Enter the amount you deposit: ");
                    customers.get(index).deposit(keyboard.nextDouble());
                    break;
                case 2: //withdraw
                     out.println("Enter the amount you withdraw: ");
                    customers.get(index).withdraw(keyboard.nextDouble());
                    break;
                case 3: //display current values in the account
                    out.println();
                    out.println(customers.get(index));
                    out.println();
                    break;
                case 4: //exit
                    break;
                default: //not 1-4 causes an error
                    out.println("Enter a vaild number");
            }
        }while(custInput != 4); //exit
    }
   
}
