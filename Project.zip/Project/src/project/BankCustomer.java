package project;
import static java.lang.System.out;
 class BankCustomer 
{
    private int CustomerID; //holds the customer ID
    private double balance; //holds tha balance
    private double interestEarned; //holds the earned interest
    private String name; //holds the customername
    private String email; //holds the customer email
    public AccountType account; //holds an object of AccountType
    
    public BankCustomer() //default constructor, sets all to defaults
    {
        CustomerID = 0;
        balance =0;
        interestEarned =0;
        name = "";
        email ="";
        account = new AccountType();
    }
    public BankCustomer(int CustomerID, double balance, String name, String email, int AccountID) //overloaded constructor
    {
        this.CustomerID = CustomerID; //user defined customer id
        this.balance = balance; //starting balance
        this.interestEarned =0; //earned interest to 0
        this.name = name; //holds the name
        this.email = email;
        account = new AccountType(AccountID);//sets the account type
    }
    public void deposit(double value)//deposit method
    {
        if(value <= 0)//if negative give an error
            out.println("Entry error with deposit amount");
        else //add to balance
            balance +=value;
    }
    public void withdraw(double value) //withdraw method
    {
        if(value <=0)//.if negative give an error
            out.println("Error with withdraw amount");
        else //withdraw from balance
            balance -= value;
    }
    public double getBalance() //returns the current balance
    {
        return balance;
    }
    public double getCustomerID() //returns the current CustomerID
    {
        return CustomerID;
    }
    public void setCustomerID(int CustomerID) //change the CustomerID (more for manager)
    {
        this.CustomerID = CustomerID;
    }
     public String getName() //returns the current Customer Name
    {
        return name;
    }
    public void setName(String name) //change the Customer name
    {
        this.name = name;
    }
     public String getEmail() //returns the current email
    {
        return email;
    }
    public void setEmail(String email) //change the email
    {
        this.email = email;
    }
    public double getInterest() //calcuate and display interestEarned, can be more complex with compound and monthly
    {
        double amount = account.getInterestRate() * balance; //simple interest earned formula
        balance += amount;//adds the interest to balance
        interestEarned += amount;
        return amount; //returns if desired
    }
    @Override
    public String toString() //to display the record values that matter
    {
        return "Customer Name: " + name + " Balance: $" + balance + " Interest Earned: $" + interestEarned;
    }
}
