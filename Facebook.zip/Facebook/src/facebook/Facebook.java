package facebook;
import static java.lang.System.*;
import java.text.DecimalFormat;
import java.util.Scanner;
/**
 *
 * @author trgie
 */
public class Facebook 
{

   
    public static void main(String[] args) 
    {
        FacebookUsers users = new FacebookUsers(); //object of the facebookUsers class
        Scanner input = new Scanner(in);//keyboard entry of data
 
        double userinput = -1; //userinput set to a non-valid number by default
        do
        {
            out.print("Please enter how many active Facebook users for 2017 in the Millions: ");
            userinput = input.nextDouble();//gets the users value
            if(userinput <= 0) //if invaild displays a try again message
                out.println("Please enter a vaild number and try again0");
        } while(userinput < 0); //will loop until valid
        users.setUsers(userinput);//assigns the vaild number to the users value
         out.println("Year  FB Users in Millions"); //table header
         
        for(int i = 2017; i <= 2021; i ++) //loops for 2017-2021
        {
            out.println(i + users.toString()); //outputs year + FacebookUsers override ToString() method
            users.increase(); //calls a method that increases users value by 10%
        }
        
    }
    
}
