package facebook;


import java.text.DecimalFormat;

public class FacebookUsers 
{
    
    private double users; //holds the users per million
    
    public FacebookUsers() //default constructor
    {
          users = 0;//default of zero users      
               
    }
    public FacebookUsers(double users)//overloaded constructor
    {
        this.users = users;//assigns the users value to users
     
    }
    public double getUsers() //returns value of user
    {
        return users;
    }
    public void setUsers(double users)//sets the value of users
    {
        this.users = users;
    }
   public void increase()//increases users by 10%
   {
       users *=1.1;
   }
   public String toString()//helps display the table
   {
      
    DecimalFormat df = new DecimalFormat("##.###");//used to format to 3 decimal places
        
     return  "  " + df.format(users);
          
   }
}
